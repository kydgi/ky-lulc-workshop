import arcpy

NLCD_SERVICE = (
    "https://kyraster.ky.gov/arcgis/rest/services/ThematicServices/"
    "Ky_Annual_NLCD_{year}_30M/ImageServer"
)

LOOKUP_NLCD = {
    11: "Open Water",
    21: "Developed, Open Space",
    22: "Developed, Low Intensity",
    23: "Developed, Medium Intensity",
    24: "Developed, High Intensity",
    31: "Barren Land (Rock/Sand/Clay)",
    41: "Deciduous Forest",
    42: "Evergreen Forest",
    43: "Mixed Forest",
    52: "Shrub/Scrub",
    71: "Grassland/Herbaceous",
    81: "Pasture/Hay",
    82: "Cultivated Crops",
    90: "Woody Wetlands",
    95: "Emergent Herbaceous Wetlands",
}

CELL_SIZE_FT = 98.425          # cell size in feet (State Plane KY)
SQ_MI_PER_SQ_FT = 1 / 2.788e7 # sq ft to sq mi conversion


class Toolbox:
    def __init__(self):
        self.label = "NLCD Change Analysis"
        self.alias = "nlcd_change"
        self.tools = [LandCoverChange]


class LandCoverChange:
    def __init__(self):
        self.label = "Land Cover Change"
        self.description = (
            "Computes land cover change between two NLCD years for a given "
            "area of interest and writes a summary change table."
        )
        self.canRunInBackground = True

    # ------------------------------------------------------------------
    # Parameterz
    # ------------------------------------------------------------------
    def getParameterInfo(self):
        start_year = arcpy.Parameter(
            displayName="Start Year",
            name="start_year",
            datatype="GPLong",
            parameterType="Required",
            direction="Input",
        )
        start_year.value = 1985

        end_year = arcpy.Parameter(
            displayName="End Year",
            name="end_year",
            datatype="GPLong",
            parameterType="Required",
            direction="Input",
        )
        end_year.value = 2024

        aoi = arcpy.Parameter(
            displayName="Area of Interest",
            name="aoi",
            datatype="GPFeatureRecordSetLayer",
            parameterType="Required",
            direction="Input",
        )
        aoi.value = arcpy.FeatureSet()

        change_type = arcpy.Parameter(
            displayName="Change Type",
            name="change_type",
            datatype="GPString",
            parameterType="Required",
            direction="Input",
        )
        change_type.filter.type = "ValueList"
        change_type.filter.list = [
            "To Developed",
            "To Forest",
            "To Open Land",
            "Any Change",
        ]
        change_type.value = "To Developed"

        output_raster = arcpy.Parameter(
            displayName="Output Change Raster",
            name="output_raster",
            datatype="DERasterDataset",
            parameterType="Required",
            direction="Output",
        )

        output_table = arcpy.Parameter(
            displayName="Output Summary Table",
            name="output_table",
            datatype="DETable",
            parameterType="Required",
            direction="Output",
        )

        output_start_raster = arcpy.Parameter(
            displayName="Output Start Year Raster (optional)",
            name="output_start_raster",
            datatype="DERasterDataset",
            parameterType="Optional",
            direction="Output",
        )

        output_end_raster = arcpy.Parameter(
            displayName="Output End Year Raster (optional)",
            name="output_end_raster",
            datatype="DERasterDataset",
            parameterType="Optional",
            direction="Output",
        )

        return [start_year, end_year, aoi, change_type, output_raster, output_table,
                output_start_raster, output_end_raster]

    def isLicensed(self):
        return arcpy.CheckExtension("Spatial") == "Available"

    def updateParameters(self, parameters):
        return

    def updateMessages(self, parameters):
        start = parameters[0].value
        end = parameters[1].value
        if start and end and start >= end:
            parameters[1].setErrorMessage("End Year must be greater than Start Year.")
        aoi = parameters[2].value
        if aoi and hasattr(aoi, "JSON"):
            import json
            geom_type = json.loads(aoi.JSON).get("geometryType", "")
            if geom_type and geom_type != "esriGeometryPolygon":
                parameters[2].setErrorMessage("Area of Interest must be a polygon layer.")
        return

    # ------------------------------------------------------------------
    # Execution
    # ------------------------------------------------------------------
    def execute(self, parameters, messages):
        start_year  = parameters[0].value
        end_year    = parameters[1].value
        aoi_input         = parameters[2].value          # FeatureSet or layer
        change_type       = parameters[3].valueAsText
        out_raster        = parameters[4].valueAsText
        out_table         = parameters[5].valueAsText
        out_start_raster  = parameters[6].valueAsText
        out_end_raster    = parameters[7].valueAsText

        arcpy.CheckOutExtension("Spatial")
        arcpy.env.overwriteOutput = True

        # ── ?? AOI as a feature class ?? ─────────────────────
        aoi = arcpy.CreateScratchName("aoi", "", "FeatureClass", arcpy.env.scratchGDB)
        arcpy.management.CopyFeatures(aoi_input, aoi)

        # ── Load and clip rasters ───────────────────────────────────
        start_url = NLCD_SERVICE.format(year=start_year)
        end_url   = NLCD_SERVICE.format(year=end_year)
        arcpy.env.extent = aoi   # anchor image service requests to AOI extent
        messages.addMessage(f"Extracting {start_year} raster by AOI…")
        a = arcpy.sa.ExtractByMask(start_url, aoi)
        messages.addMessage(f"Extracting {end_year} raster by AOI…")
        b = arcpy.sa.ExtractByMask(end_url, aoi)
        arcpy.env.extent = "MAXOF"    # restore default

        if out_start_raster:
            a.save(out_start_raster)
            messages.addMessage(f"Start raster saved: {out_start_raster}")
        if out_end_raster:
            b.save(out_end_raster)
            messages.addMessage(f"End raster saved: {out_end_raster}")

        # ── Compute change raster ───────────────────────────────────
        messages.addMessage(f"Computing change: {change_type}…")
        change = _compute_change(a, b, change_type)
        change.save(out_raster)
        messages.addMessage(f"Change raster saved: {out_raster}")

        # ── Build statistics for start and end ─────────────────────
        messages.addMessage("Calculating per-class statistics…")
        start_stats = _calc_stats(a)
        end_stats   = _calc_stats(b)

        # ── Write summary table ─────────────────────────────────────
        _write_table(out_table, start_stats, end_stats, messages)
        messages.addMessage(f"Summary table saved: {out_table}")

        # ── Change raster summary ───────────────────────────────────
        _summarize_change(out_raster, change_type, messages)

        arcpy.CheckInExtension("Spatial")

    def postExecute(self, parameters):
        return


# ======================================================================
# Functions
# ======================================================================

def _calc_stats(raster):
    """Return {nlcd_value: area_sq_mi} by reading the raster's RAT."""
    stats = {}
    # Save to memory so SearchCursor can access the RAT
    tmp_path = arcpy.CreateScratchName("nlcd_tmp", "", "RasterDataset", arcpy.env.scratchGDB)
    raster.save(tmp_path)
    rows = arcpy.SearchCursor(tmp_path, "", "", "Count; Value")
    for row in rows:
        value = int(row.getValue("VALUE"))
        count = row.getValue("COUNT")
        area  = (count * CELL_SIZE_FT ** 2) * SQ_MI_PER_SQ_FT
        stats[value] = round(area, 2)
    arcpy.management.Delete(tmp_path)
    return stats


def _compute_change(a, b, change_type):
    """Return a binary raster: 1 = changed, 0 = no change."""
    if change_type == "To Developed":
        return ((a < 21) | (a >= 30)) & ((b >= 21) & (b < 30))
    elif change_type == "To Forest":
        return ((a < 41) | (a >= 52)) & ((b >= 41) & (b < 52))
    elif change_type == "To Open Land":
        return (((a > 21) & (a < 31)) | ((a >= 41) & (a < 52))) & (((b > 43) & (b <= 82)) | (b == 21))
    else:  # Any Change
        return arcpy.sa.Con(a != b, 1, 0)


def _summarize_change(raster_path, change_type, messages):
    """Read the saved change raster RAT and print area/percent summary."""
    counts = {}
    rows = arcpy.SearchCursor(raster_path, "", "", "Count; Value")
    for row in rows:
        counts[int(row.getValue("VALUE"))] = row.getValue("COUNT")

    changed  = counts.get(1, 0)
    no_change = counts.get(0, 0)
    total    = changed + no_change

    if total == 0:
        messages.addMessage("Change summary: no valid pixels found.")
        return

    area_total   = round((total   * CELL_SIZE_FT ** 2) * SQ_MI_PER_SQ_FT, 2)
    area_changed = round((changed * CELL_SIZE_FT ** 2) * SQ_MI_PER_SQ_FT, 2)
    pct_changed  = round((changed / total) * 100, 2)

    messages.addMessage("-" * 48)
    messages.addMessage(f"Change Summary  [{change_type}]")
    messages.addMessage(f"  Total area covered : {area_total:,.2f} sq mi")
    messages.addMessage(f"  Area changed       : {area_changed:,.2f} sq mi")
    messages.addMessage(f"  Percent changed    : {pct_changed:.2f}%")
    messages.addMessage("-" * 48)


def _write_table(table_path, start_stats, end_stats, messages):
    """Create the output table and populate one row per NLCD class."""
    ws, tbl = table_path.rsplit("\\", 1) if "\\" in table_path else ("", table_path)
    arcpy.management.CreateTable(ws or arcpy.env.workspace, tbl)

    arcpy.management.AddField(table_path, "Value",      "LONG")
    arcpy.management.AddField(table_path, "Class",      "TEXT",   field_length=60)
    arcpy.management.AddField(table_path, "Start_Area", "DOUBLE")
    arcpy.management.AddField(table_path, "End_Area",   "DOUBLE")
    arcpy.management.AddField(table_path, "Change",     "DOUBLE")

    fields = ["Value", "Class", "Start_Area", "End_Area", "Change"]
    with arcpy.da.InsertCursor(table_path, fields) as cursor:
        for value, label in LOOKUP_NLCD.items():
            s = start_stats.get(value, 0.0)
            e = end_stats.get(value, 0.0)
            cursor.insertRow((value, label, s, e, round(e - s, 2)))
            messages.addMessage(f"  {label}: {s} → {e} sq mi (Δ {round(e-s,2)})")
